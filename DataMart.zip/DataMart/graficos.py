import pandas as pd

df = pd.read_excel('datamart_nordeste_2021.xlsx')

# Filtro para a Região Nordeste
df_nordeste = df[df['Nome da Grande Região'] == 'Nordeste']

# Soma dos setores econômicos
setores = {
    'Agropecuária': df_nordeste['Valor adicionado bruto da Agropecuária, \na preços correntes\n(R$ 1.000)'].sum(),
    'Indústria': df_nordeste['Valor adicionado bruto da Indústria,\na preços correntes\n(R$ 1.000)'].sum(),
    'Serviços': df_nordeste['Valor adicionado bruto dos Serviços,\na preços correntes \n- exceto Administração, defesa, educação e saúde públicas e seguridade social\n(R$ 1.000)'].sum(),
    'Administração Pública': df_nordeste['Valor adicionado bruto da Administração, defesa, educação e saúde públicas e seguridade social, \na preços correntes\n(R$ 1.000)'].sum()
}

# Converte para DataFrame
df_setores = pd.DataFrame(list(setores.items()), columns=['Setor Econômico', 'Valor Total (R$ 1.000)'])

# Exibe a tabela que você vai usar no Canva
print(df_setores)

# (Opcional) Salvar em CSV para copiar/colar no Canva
df_setores.to_csv('grafico_setores_nordeste.csv', index=False)
