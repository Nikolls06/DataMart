import pandas as pd

# Carrega o arquivo original
df = pd.read_excel("PIB DOS MUNICÍPIOS DO BRASIL.xlsx")  # Substitua com o nome correto do seu arquivo

# Filtra apenas os dados da Região Nordeste e do ano de 2021
df_nordeste_2021 = df[(df['Nome da Grande Região'] == 'Nordeste') & (df['Ano'] == 2021)]  # Ajuste os nomes das colunas se necessário

# Salva o resultado como novo Excel
df_nordeste_2021.to_excel("datamart_nordeste_2021.xlsx", index=False)

print("Data Mart da Região Nordeste (2021) gerado com sucesso!")
