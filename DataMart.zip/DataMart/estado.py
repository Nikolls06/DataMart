import pandas as pd

# Carrega os dados
df = pd.read_excel('datamart_nordeste_2021.xlsx')  # ou pd.read_csv(...)

# Filtra só municípios do Nordeste
df_nordeste = df[df['Nome da Grande Região'] == 'Nordeste']

# Calcula a média do PIB per capita por estado
df_pib_estado = df_nordeste.groupby('Sigla da Unidade da Federação')[
    'Produto Interno Bruto per capita, \na preços correntes\n(R$ 1,00)'
].mean().reset_index()

# Renomeia colunas para facilitar uso no Canva
df_pib_estado.columns = ['Estado', 'PIB per capita médio (R$)']

# Exibe os dados
print(df_pib_estado)

# (opcional) salva em CSV para importar no Canva
df_pib_estado.to_csv('pib_per_capita_estados_nordeste.csv', index=False)
